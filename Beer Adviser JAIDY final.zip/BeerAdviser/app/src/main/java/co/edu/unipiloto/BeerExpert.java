package co.edu.unipiloto;

import java.util.ArrayList;
import java.util.List;
public class BeerExpert {
    List<String> getBrands(String color) {
        List<String> brands = new ArrayList<>();
        if (color.equals("Reglamentaria")) {
            brands.add("No pase");
            brands.add("Pare");
            brands.add("Prohibido parquear");
            } else if (color.equals("Preventiva")) {
            brands.add("Zona de derrumbe");
            brands.add("Intersección");
            brands.add("Puente angosto");
            }else if (color.equals("Informativa")) {
                brands.add("Hospital");
                brands.add("Restaurante");
                brands.add("Museo");
            }else {
            brands.add("Carril izquierdo cerrado");
            brands.add("Inicio y fin de obra");
            brands.add("Obra en la via 100m");

        }
        return brands;
    }
}